package com.ryy.giftlist.bean;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named
@RequestScoped
public class HolaMundoBean {
	private String mensaje = "¡Hola desde JSF!";

    public String getMensaje() {
        return mensaje;
    }

    public void saludar() {
        mensaje = "¡Hola Mundo, este es un mensaje generado con JSF!";
    }
}
